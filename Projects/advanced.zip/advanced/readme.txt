Projekt: Snake – Advanced version
Kursus: 02104 Introductory Programming Project in Software Technology

Beskrivelse:
Denne version bygger videre på Simple Snake og indeholder en række udvidelser og forbedringer.
Spillet bevæger sig automatisk i faste tidsintervaller, hvilket introducerer tidspres for
spilleren. Derudover er der tilføjet animationer og en sejrstilstand.

Spillet kan vindes, hvis slangen vokser til at fylde hele banen. Programmet opretholder
yderligere intern tilstand for at understøtte animation og mere flydende bevægelse.

Udvidelser:
- Tidspres (automatisk bevægelse)
- Animation af slangens bevægelse
- Sejrstilstand når hele banen er udfyldt
- Udvidet spiltilstandshåndtering

Kørsel:
java -jar snake.jar n m

hvor:
n = antal rækker (5–100)
m = antal kolonner (5–100)

Eksempel:
java -jar snake.jar 20 20

Krav:
Java 17 eller nyere

Indhold:
- Eksekverbar jar-fil
- Fuld kildekode (src/)
- Grafiske og øvrige ressourcer
