Projekt: Snake – Simple version
Kursus: 02104 Introductory Programming Project in Software Technology

Beskrivelse:
Denne version implementerer den grundlæggende udgave af Snake-spillet som beskrevet i
opgaveformuleringen. Spillet foregår på en todimensionel torus, hvor slangen styres via
tastaturinput og kun bevæger sig, når spilleren giver input. Der er ingen automatisk
tidsstyring.

Slangen vokser, når den spiser mad, og spillet slutter ved kollision med slangens egen krop
(bortset fra halen). Banens størrelse angives ved opstart.

Kørsel:
java -jar snake.jar n m

hvor:
n = antal rækker (5–100)
m = antal kolonner (5–100)

Eksempel:
java -jar snake.jar 20 20

Krav:
Java 17 eller nyere

Indhold:
- Eksekverbar jar-fil
- Fuld kildekode (src/)
- Grafiske og øvrige ressourcer
